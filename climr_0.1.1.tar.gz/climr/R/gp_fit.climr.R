#' Fit basic statistical models to climate data
#'
#' @param obj An object of class \code{climr} from \code{\link{load_clim}}
#' @param fit_type The type of model required general purpose optimization (\code{optim})
#'
#' @return Returns a list of class \code{climr_gp_fit} which includes the model details as well as the data set and gp fit type used
#' @seealso \code{\link{load_clim}}, \code{\link{plot.climr_gp_fit}}
#' @export
#' @importFrom magrittr "%$%"
#' @importFrom stats "optim"
#' @importFrom mvtnorm dmvnorm
#' @examples
#' data1 = load_clim("NH")
#' data2 = gp_fit(data1, "BFGS")
#' plot(data2)
gp_fit = function(obj, fit_type = c('Nelder-Mead', 'BFGS', 'SANN', 'Brent')) {
  UseMethod('gp_fit')
}

#' @export
gp_fit.climr = function(obj, fit_type = c('Nelder-Mead', 'BFGS', 'SANN', 'Brent')) {
  gp_criterion = function(p,x,y) {
    sig_sq = exp(p[1])
    rho_sq = exp(p[2])
    tau_sq = exp(p[3])
    Mu = rep(0, length(x))
    Sigma = sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))
    ll = dmvnorm(y, Mu, Sigma, log = TRUE)
    return(-ll)
  }

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = x = year = NULL

  # Find what type of fitting method
  fit_arg = match.arg(fit_type)

  # Call upon the regression fit --> indeed calls upon optimization and gp_criterion
  # Fit some models
  # Calculate predicted values
  #pred_lm  = X_g %*% solve(t(X)%*%X, t(X)%*%y)
  x = obj$clim_year$year
  y = obj$clim_year$temp
  x_g = pretty(x,100)
  # Find best hyperparameters
  optim_res = optim(rep(0, 3), gp_criterion, x = x, y = y, method = fit_arg)

  # Extract the results
  sig_sq = exp(optim_res$par[1])
  rho_sq = exp(optim_res$par[2])
  tau_sq = exp(optim_res$par[3])

  # Create covariance matrices
  C = sig_sq * exp( - rho_sq * outer(x_g, x, '-')^2 )
  Sigma = sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))

  # Create predictions
  pred_gp = C %*% solve(Sigma, y)
  print(pred_gp)

  # Output so it can be plotted
  out = list(pred_gp = pred_gp,
             data = obj$clim_year,
             fit_type = fit_arg)
  class(out) = 'climr_gp_fit'

  invisible(out)

}
