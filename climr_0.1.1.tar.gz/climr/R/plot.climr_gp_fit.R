#' Plot climr output
#' @param x Output from the \code{\link{fit}} function
#' @param time_grid An optional time grid over which to produce fitted values of the model
#' @param ... Other arguments to plot (not currently implemented)
#' @return Nothing: just a nice plot
#' @seealso \code{\link{load_clim}}, \code{\link{gp_fit}}
#' @export
#' @import ggplot2
#' @importFrom tibble "tibble"
#' @importFrom viridis "scale_color_viridis"
#' @examples
#' ans1 = load_clim('SH')
#' ans2 = gp_fit(ans1, fit_type = 'BFGS')
#' plot(ans2)


plot.climr_gp_fit = function(x, time_grid = pretty(x$data$year, n = 100), ...) {

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = year = NULL

  # Create a nice plot from the output of fit.climr

  # Get the data set out
  df = x$data

  # Get some predicted values based on the time_grid
  fits = tibble(time_grid, pred = x$pred_gp)

  # Finally create the plot
  ggplot(df, aes(year, temp)) +
    geom_point(aes(colour = temp)) +
    theme_bw() +
    xlab('Year') +
    ylab('Temperature anomaly') +
    geom_line(data = fits, aes(x = time_grid, y = pred, colour = pred)) +
    theme(legend.position = 'None') +
    scale_color_viridis()

}
